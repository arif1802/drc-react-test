import React, { useState, useEffect } from "react";
import InputLabel from "@material-ui/core/InputLabel";
import { makeStyles } from "@material-ui/core/styles";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import FormLabel from "@material-ui/core/FormLabel";
import { serverTableData } from "../Data/TableData";
import FormGroup from "@material-ui/core/FormGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Slider from "@material-ui/core/Slider";
import { ram } from "../Data/FilterData";
import Typography from "@material-ui/core/Typography";
import { storage } from "../Data/FilterData";

const useStyles = makeStyles((theme) => ({
  formControl: {
    margin: theme.spacing(1),
    minWidth: 150,
  },
  mb: {
    marginBottom: "50px",
  },
  selectEmpty: {
    marginTop: theme.spacing(2),
  },
}));
function Filters(props) {
  const classes = useStyles();
  const [selectedHardDiskType, setSelectedHardDiskType] = useState();
  const [selectedLocation, setSelectedLocation] = useState();
  const [locations, setLocations] = useState([]);
  const [ramData, setRamData] = useState(ram);

  useEffect(() => {
    getLocations();
  }, []);

  // Function to get the locations
  const getLocations = () => {
    const locationArray = [];
    serverTableData.map((e) => locationArray.push(e.Location));
    const removedDuplicates = locationArray.filter(function (item, pos) {
      return locationArray.indexOf(item) == pos;
    });
    setLocations(removedDuplicates);
  };

  // Function to handle the change events
  const handleChange = (event, type) => {
    if (type === "hardDiskType") {
      setSelectedHardDiskType(event.target.value);
    } else {
      setSelectedLocation(event.target.value);
    }
    props.onFilterChange(type, event.target.value);
  };

  // Function to handle the slider change event
  const handleSliderChange = (event, newValue) => {
    props.onFilterChange("storage", newValue);
  };

  // Function to handle the checkbox change event
  const handleCheckboxes = (event) => {
    let ramDataArray = ramData;
    ramDataArray.forEach((row) => {
      if (row.value === event.target.value) {
        row.checked = event.target.checked;
      }
    });
    setRamData(ramDataArray);
    props.onFilterChange("ram", ramData);
  };

  return (
    <>
      <div>
        <FormControl className={classes.formControl}>
          <InputLabel id="demo-simple-select-label">Hard Disk Type</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            name="hardDiskType"
            value={selectedHardDiskType || ""}
            onChange={(e) => {
              handleChange(e, "hardDiskType");
            }}
          >
            <MenuItem value="SAS">SAS</MenuItem>
            <MenuItem value="SATA">SATA</MenuItem>
            <MenuItem value="SSD">SSD</MenuItem>
          </Select>
        </FormControl>
        <FormControl className={classes.formControl}>
          <InputLabel id="demo-simple-select-label">Locations</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={selectedLocation || ""}
            onChange={(e) => {
              handleChange(e, "locations");
            }}
          >
            {locations.map((value, index) => (
              <MenuItem key={index} value={value}>
                {value}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl component="fieldset" className={classes.formControl}>
          <FormLabel component="legend">RAM</FormLabel>
          <FormGroup row>
            {ramData.map((row, index) => (
              <FormControlLabel
                key={index}
                control={
                  <Checkbox
                    value={row.value}
                    checked={row.checked}
                    onChange={(e) => {
                      handleCheckboxes(e, "ram");
                    }}
                    name={row.value}
                  />
                }
                label={row.value}
              />
            ))}
          </FormGroup>
        </FormControl>
      </div>

      <div className={classes.root}>
        <Typography id="discrete-slider-custom" gutterBottom>
          Storage
        </Typography>
        <Slider
          defaultValue={0}
          step={5}
          onChange={handleSliderChange}
          aria-labelledby="discrete-slider-custom"
          valueLabelDisplay="auto"
          marks={storage}
        />
      </div>
    </>
  );
}

export default Filters;
