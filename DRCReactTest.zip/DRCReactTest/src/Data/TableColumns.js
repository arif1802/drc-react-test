export default [
  { id: "Model", label: "Model", minWidth: 170 },
  { id: "RAM", label: "RAM", minWidth: 100 },
  { id: "HDD", label: "HDD", minWidth: 100 },
  { id: "Location", label: "Location", minWidth: 100 },
  { id: "Price", label: "Price", minWidth: 100 },
];
