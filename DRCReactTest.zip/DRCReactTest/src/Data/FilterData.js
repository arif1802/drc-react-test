export const ram = [
  { value: "2GB", checked: false },
  { value: "4GB", checked: false },
  { value: "8GB", checked: false },
  { value: "12GB", checked: false },
  { value: "16GB", checked: false },
  { value: "24GB", checked: false },
  { value: "32GB", checked: false },
  { value: "48GB", checked: false },
  { value: "64GB", checked: false },
  { value: "96GB", checked: false },
];

export const storage = [
  {
    value: 0,
    label: "0GB",
  },
  {
    value: 5,
    label: "250GB",
  },
  {
    value: 10,
    label: "500GB",
  },
  {
    value: 15,
    label: "1TB",
  },
  {
    value: 20,
    label: "2TB",
  },
  {
    value: 25,
    label: "3TB",
  },
  {
    value: 30,
    label: "4TB",
  },
  {
    value: 35,
    label: "8TB",
  },
  {
    value: 40,
    label: "12TB",
  },
  {
    value: 45,
    label: "24TB",
  },
  {
    value: 50,
    label: "48TB",
  },
  {
    value: 55,
    label: "72TB",
  },
];
