import React, { useState, useEffect } from "react";
import ServersTable from "./Components/ServersTable";
import { serverTableData } from "./Data/TableData";
import Filters from "./Components/Filters";
import Container from "@material-ui/core/Container";
import { storage } from "./Data/FilterData";

function App() {
  const [tableData, setTableData] = useState(serverTableData);
  const [tableFilters, setTableFilters] = useState([]);

  useEffect(() => {
    handleFilter();
  }, [tableFilters]);

  // Function to filter the table data
  const filterTableData = (type, value) => {
    setTableFilters({ ...tableFilters, [type]: value });
  };

  const handleFilter = () => {
    let filteredData = [...serverTableData];
    if (tableFilters.hardDiskType) {
      filteredData = filterHardDiskType(
        filteredData,
        tableFilters.hardDiskType
      );
    }
    if (tableFilters.locations) {
      filteredData = filterLocations(filteredData, tableFilters.locations);
    }
    if (tableFilters.ram) {
      filteredData = filterRAM(filteredData, tableFilters.ram);
    }
    if (tableFilters.storage) {
      filteredData = filterStorage(filteredData, tableFilters.storage);
    }
    setTableData(filteredData);
  };

  // Function to filter the hard disk type
  const filterHardDiskType = (data, value) => {
    return data.filter((e) => e.HDD.includes(value));
  };

  // Function to filter the storage
  const filterStorage = (data, value) => {
    const sliderValue = storage.filter((e) => e.value === value);
    if (sliderValue && sliderValue.length && sliderValue[0].label != "0GB") {
      const filteredData = data.filter((e) => {
        let tableDataArray = e.HDD.split("x");
        let subStr = tableDataArray[1].substring(0, 5);
        const numbersStrings = subStr.replace(/\D/g, "");
        let sliderNumberValue = sliderValue[0].label.replace(/\D/g, "");
        let sliderStringValue = sliderValue[0].label.replace(/[^a-zA-Z]+/g, "");
        if (sliderStringValue == "GB") {
          return numbersStrings <= sliderNumberValue && !e.HDD.includes("TB");
        } else {
          if (e.HDD.includes("GB")) {
            return e;
          } else if (
            e.HDD.includes("TB") &&
            numbersStrings <= sliderNumberValue
          ) {
            return e;
          }
        }
      });
      return filteredData;
    }
    return data;
  };

  // Function to filter locations
  const filterLocations = (data, value) => {
    return data.filter((e) => e.Location.includes(value));
  };

  // Function to filter RAM
  const filterRAM = (data, value) => {
    const checkedArray = [];
    value.filter((e) => {
      if (e.checked) {
        checkedArray.push(e.value);
      }
    });
    if (checkedArray.length) {
      const filteredData = data.filter((e) => {
        const extractedValue = e.RAM.split("GB");
        if (checkedArray.indexOf(extractedValue[0] + "GB") !== -1) {
          return e;
        }
      });
      return filteredData;
    }
    return data;
  };

  return (
    <div className="App">
      <Container maxWidth="lg">
        <Filters onFilterChange={filterTableData} />
        <ServersTable serverTableData={tableData} />
      </Container>
    </div>
  );
}

export default App;
